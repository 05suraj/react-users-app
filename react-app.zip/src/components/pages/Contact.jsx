const content = {

  inputs:[
  {
    label :'Username',
    name:"username",
    type:"text"
  },
   {
    label :'Email',
    name:"email",
    type:"text"
  },
   {
    label :'Password',
    name:"password",
    type:"text"
  }
]

}
  
 export default content